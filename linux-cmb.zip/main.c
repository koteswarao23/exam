/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<stdlib.h>
#include <stdio.h>
#include<string.h>

int main(int arg,char *argc[])
{
  char *cmd[10];
    char *c;
    int i,n=0;
    while(1)
    {
          c=malloc(10);
           scanf("%s",c);
           int t =strcmp(c,"exit");
           if(t!=0)
           cmd[n++]=c;
        else
           break;
    }
   
    for(i=0;i<n;i++)
    printf("%d\t%s\n",i+1,cmd[i]);
}
